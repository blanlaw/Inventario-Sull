package com.argo.inventario_service.movimientos.domain.enm;

public enum estadoMovimiento {

    EN_CAMINO,ENTREGADO,ESPERA_CONFIRMACION
}
