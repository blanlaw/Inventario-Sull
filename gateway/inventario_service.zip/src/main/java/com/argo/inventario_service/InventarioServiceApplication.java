package com.argo.inventario_service;


import com.argo.inventario_service.requerimiento.application.RequerimientoService;
import com.argo.inventario_service.requerimiento.application.models.DetallesRequerimientoModel;
import com.argo.inventario_service.requerimiento.application.models.RequerimientoModel;
import com.argo.inventario_service.requerimiento.application.models.RequerimientoModelTraslado;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@EntityScan({"com.commons.user.models.entity", "com.argo.inventario_service"})
@EnableFeignClients
@EnableEurekaClient
@SpringBootApplication
public class InventarioServiceApplication implements CommandLineRunner {


    @Autowired
    private RequerimientoService requerimientoService;


    public static void main(String[] args) {
        SpringApplication.run(InventarioServiceApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {


        DetallesRequerimientoModel list = new DetallesRequerimientoModel();
        list.setCantidad(12);
        list.setCodigo("EPP-001");

        String token = "Bearer " + "ya29.a0AfH6SMCG5SoU4TxZ2gk0XtuqnHdH9VGyYPveuVIJWVQs0kEClCu2V0duYVVFAHb5fb8v1AX71CwfAlTRJZeCKWzYuMKZXLsuQHHpKYbvf-TVU2LEmyNJ1zRX8ysRvKKAULpZjjOR1ZJFMpvvExDYvz85tzf46PzkY_3qubo5wAV4";


        List aa = new ArrayList();
        aa.add(list);


        RequerimientoModelTraslado modelo = new RequerimientoModelTraslado(1,new Date(),"ninguna",aa);



    }

    public void general(String token, List aa) {
        RequerimientoModel model = new RequerimientoModel(new Date(), "ninguna", aa);

        this.requerimientoService.crearRequerimientoGeneral(model, token);
    }
}
