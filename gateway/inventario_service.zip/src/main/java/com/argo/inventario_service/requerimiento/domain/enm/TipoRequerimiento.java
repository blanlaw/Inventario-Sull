package com.argo.inventario_service.requerimiento.domain.enm;

public enum TipoRequerimiento {

    NOSTOCK, NECESIDAD
}
