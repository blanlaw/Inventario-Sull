package com.argo.inventario_service.dashboard.models;

import java.util.Date;

public interface requerimientoModelDashboard {


    String getCodigo();

    Date getFechaEmision();

    String getAlmacenRequiere();
}
