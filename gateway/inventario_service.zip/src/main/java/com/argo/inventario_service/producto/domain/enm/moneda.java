package com.argo.inventario_service.producto.domain.enm;

public enum moneda {
    PEN,USD
}
