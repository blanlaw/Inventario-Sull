package com.argo.inventario_service.requerimiento.domain.enm;

public enum EstadoRequerimiento {
    ESPERA,REVISADO,ACEPTADO,RECHAZADO,INTERNO,ESPERA_CONFIRMACION,REVISADO_CONFIRMADO
}
