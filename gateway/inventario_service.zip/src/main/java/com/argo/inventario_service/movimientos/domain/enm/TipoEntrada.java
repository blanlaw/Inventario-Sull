package com.argo.inventario_service.movimientos.domain.enm;

public enum TipoEntrada {
    TRASLADO,COMPRA
}
