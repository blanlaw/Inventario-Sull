package com.argo.eurekadiscover;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekadiscoverApplicationTests {

    @Test
    void contextLoads() {
    }

}
